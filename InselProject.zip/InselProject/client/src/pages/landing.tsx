import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-background"></div>
        <div className="relative container mx-auto px-4 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex items-center justify-center space-x-4 mb-8">
              <div className="w-20 h-20 gold-gradient rounded-2xl flex items-center justify-center">
                <i className="fas fa-crown text-primary-foreground text-3xl"></i>
              </div>
              <div className="text-left">
                <h1 className="text-4xl md:text-6xl font-bold text-primary">MAMMON</h1>
                <p className="text-xl md:text-2xl text-foreground font-medium">INVESTIMENTOS</p>
              </div>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-foreground">
              Plataforma Premium de <span className="text-primary">Investimentos</span>
            </h2>
            
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Rendimentos exclusivos de <span className="text-primary font-bold">200%</span> em apenas <span className="text-primary font-bold">3 dias corridos</span>
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg" 
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg font-semibold"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-login"
              >
                <i className="fas fa-sign-in-alt mr-2"></i>
                Acessar Plataforma
              </Button>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <i className="fas fa-shield-check text-primary"></i>
                <span>Seguro e Garantido</span>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">200%</div>
                <div className="text-muted-foreground">Retorno Garantido</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">3</div>
                <div className="text-muted-foreground">Dias Corridos</div>
              </div>
              <div className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">24/7</div>
                <div className="text-muted-foreground">Suporte Premium</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              Por que escolher o <span className="text-primary">MAMMON</span>?
            </h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              A plataforma mais confiável e rentável do mercado brasileiro
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            <Card className="bg-card border-border premium-shadow">
              <CardHeader className="text-center pb-2">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-chart-line text-primary text-2xl"></i>
                </div>
                <CardTitle className="text-primary">Alto Rendimento</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Rentabilidade de 200% em apenas 3 dias corridos, garantida e auditada.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card border-border premium-shadow">
              <CardHeader className="text-center pb-2">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-shield-check text-primary text-2xl"></i>
                </div>
                <CardTitle className="text-primary">Segurança Total</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Plataforma protegida com criptografia avançada e auditoria independente.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card border-border premium-shadow">
              <CardHeader className="text-center pb-2">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-clock text-primary text-2xl"></i>
                </div>
                <CardTitle className="text-primary">Rapidez</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Processamento instantâneo e saque automático no vencimento.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="bg-card border-border premium-shadow">
              <CardHeader className="text-center pb-2">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-headset text-primary text-2xl"></i>
                </div>
                <CardTitle className="text-primary">Suporte 24/7</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center">
                  Atendimento exclusivo e personalizado para nossos investidores.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Investment Plans Preview */}
      <div className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
              Planos de <span className="text-primary">Investimento</span>
            </h3>
            <p className="text-lg text-muted-foreground">
              Escolha o valor ideal para maximizar seus lucros
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="bg-card border-border premium-shadow">
              <CardHeader>
                <CardTitle className="text-center text-primary">Tabela de Rendimentos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-4 font-semibold text-primary">Investimento</th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">Retorno (200%)</th>
                        <th className="text-left py-3 px-4 font-semibold text-primary">Lucro Líquido</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      <tr className="hover:bg-muted/30 transition-colors">
                        <td className="py-3 px-4 font-medium">R$ 50,00</td>
                        <td className="py-3 px-4 text-green-400 font-bold">R$ 150,00</td>
                        <td className="py-3 px-4 text-primary font-semibold">R$ 100,00</td>
                      </tr>
                      <tr className="hover:bg-muted/30 transition-colors">
                        <td className="py-3 px-4 font-medium">R$ 500,00</td>
                        <td className="py-3 px-4 text-green-400 font-bold">R$ 1.500,00</td>
                        <td className="py-3 px-4 text-primary font-semibold">R$ 1.000,00</td>
                      </tr>
                      <tr className="hover:bg-muted/30 transition-colors">
                        <td className="py-3 px-4 font-medium">R$ 1.000,00</td>
                        <td className="py-3 px-4 text-green-400 font-bold">R$ 3.000,00</td>
                        <td className="py-3 px-4 text-primary font-semibold">R$ 2.000,00</td>
                      </tr>
                      <tr className="hover:bg-muted/30 transition-colors">
                        <td className="py-3 px-4 font-medium">R$ 5.000,00</td>
                        <td className="py-3 px-4 text-green-400 font-bold">R$ 15.000,00</td>
                        <td className="py-3 px-4 text-primary font-semibold">R$ 10.000,00</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-20 bg-gradient-to-r from-primary/20 to-secondary/20">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-6 text-foreground">
            Comece a Investir <span className="text-primary">Hoje Mesmo</span>
          </h3>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Junte-se aos milhares de investidores que já descobriram o poder do MAMMON
          </p>
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg font-semibold"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login-cta"
          >
            <i className="fas fa-rocket mr-2"></i>
            Começar Agora
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-8 h-8 gold-gradient rounded-lg flex items-center justify-center">
                <i className="fas fa-crown text-primary-foreground text-sm"></i>
              </div>
              <div>
                <h3 className="font-bold text-primary">MAMMON INVESTIMENTOS</h3>
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-4">Plataforma premium de investimentos de alta rentabilidade</p>
            <div className="flex justify-center space-x-6 text-xs text-muted-foreground">
              <a href="#" className="hover:text-primary transition-colors">Termos de Uso</a>
              <a href="#" className="hover:text-primary transition-colors">Política de Privacidade</a>
              <a href="#" className="hover:text-primary transition-colors">Suporte</a>
              <a href="#" className="hover:text-primary transition-colors">Contato</a>
            </div>
            <p className="text-xs text-muted-foreground mt-4">© 2024 Mammon Investimentos. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
