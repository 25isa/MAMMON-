import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCPF, formatPhone, validateCPF, isUnauthorizedError } from "@/lib/utils";

const updateProfileSchema = z.object({
  fullName: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  phone: z.string().min(10, "Telefone deve ter pelo menos 10 dígitos"),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().length(5, "Senha deve ter 5 dígitos").regex(/^\d+$/, "Apenas números"),
  newPassword: z.string().length(5, "Senha deve ter 5 dígitos").regex(/^\d+$/, "Apenas números"),
  confirmPassword: z.string().length(5, "Senha deve ter 5 dígitos").regex(/^\d+$/, "Apenas números"),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Senhas não coincidem",
  path: ["confirmPassword"],
});

type UpdateProfileForm = z.infer<typeof updateProfileSchema>;
type ChangePasswordForm = z.infer<typeof changePasswordSchema>;

export default function ContaTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentPasswordInputs, setCurrentPasswordInputs] = useState<string[]>(["", "", "", "", ""]);
  const [newPasswordInputs, setNewPasswordInputs] = useState<string[]>(["", "", "", "", ""]);
  const [confirmPasswordInputs, setConfirmPasswordInputs] = useState<string[]>(["", "", "", "", ""]);

  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const profileForm = useForm<UpdateProfileForm>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      fullName: user?.fullName || "",
      email: user?.email || "",
      phone: user?.phone || "",
    },
  });

  const passwordForm = useForm<ChangePasswordForm>({
    resolver: zodResolver(changePasswordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Reset form when user data loads
  useState(() => {
    if (user) {
      profileForm.reset({
        fullName: user.fullName || "",
        email: user.email || "",
        phone: user.phone || "",
      });
    }
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: UpdateProfileForm) => {
      return await apiRequest("PUT", "/api/profile", data);
    },
    onSuccess: () => {
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro ao atualizar",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: ChangePasswordForm) => {
      return await apiRequest("PUT", "/api/change-password", {
        currentPassword: data.currentPassword,
        newPassword: data.newPassword,
      });
    },
    onSuccess: () => {
      toast({
        title: "Senha alterada!",
        description: "Sua senha foi alterada com sucesso.",
      });
      passwordForm.reset();
      setCurrentPasswordInputs(["", "", "", "", ""]);
      setNewPasswordInputs(["", "", "", "", ""]);
      setConfirmPasswordInputs(["", "", "", "", ""]);
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro ao alterar senha",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePasswordChange = (
    type: 'current' | 'new' | 'confirm',
    index: number, 
    value: string
  ) => {
    if (!/^\d*$/.test(value)) return;
    
    const setInputs = type === 'current' ? setCurrentPasswordInputs : 
                     type === 'new' ? setNewPasswordInputs : setConfirmPasswordInputs;
    const inputs = type === 'current' ? currentPasswordInputs : 
                   type === 'new' ? newPasswordInputs : confirmPasswordInputs;
    
    const newInputs = [...inputs];
    newInputs[index] = value;
    setInputs(newInputs);
    
    const password = newInputs.join("");
    const fieldName = type === 'current' ? 'currentPassword' : 
                     type === 'new' ? 'newPassword' : 'confirmPassword';
    passwordForm.setValue(fieldName, password);

    // Auto-focus next input
    if (value && index < 4) {
      const nextInput = document.querySelector(
        `input[data-password-${type}-index="${index + 1}"]`
      ) as HTMLInputElement;
      nextInput?.focus();
    }
  };

  const handlePhoneChange = (value: string) => {
    const formatted = formatPhone(value);
    profileForm.setValue("phone", formatted.replace(/\D/g, ""));
    return formatted;
  };

  const onUpdateProfile = (data: UpdateProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const onChangePassword = (data: ChangePasswordForm) => {
    changePasswordMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-primary text-3xl mb-4"></i>
          <p className="text-muted-foreground">Carregando dados da conta...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          Minha <span className="text-primary">Conta</span>
        </h2>
        <p className="text-muted-foreground">Gerencie suas informações pessoais e configurações</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-user-edit text-primary mr-3"></i>
                Informações Pessoais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={profileForm.handleSubmit(onUpdateProfile)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fullName">Nome Completo</Label>
                    <Input
                      id="fullName"
                      {...profileForm.register("fullName")}
                      className="input-gold"
                      data-testid="input-profile-fullname"
                    />
                    {profileForm.formState.errors.fullName && (
                      <p className="text-sm text-destructive mt-1">
                        {profileForm.formState.errors.fullName.message}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      {...profileForm.register("email")}
                      className="input-gold"
                      data-testid="input-profile-email"
                    />
                    {profileForm.formState.errors.email && (
                      <p className="text-sm text-destructive mt-1">
                        {profileForm.formState.errors.email.message}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Telefone</Label>
                    <Input
                      id="phone"
                      onChange={(e) => {
                        e.target.value = handlePhoneChange(e.target.value);
                      }}
                      defaultValue={user?.phone ? formatPhone(user.phone) : ""}
                      className="input-gold"
                      maxLength={15}
                      data-testid="input-profile-phone"
                    />
                    {profileForm.formState.errors.phone && (
                      <p className="text-sm text-destructive mt-1">
                        {profileForm.formState.errors.phone.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label>CPF</Label>
                    <Input
                      value={user?.cpf ? formatCPF(user.cpf) : ""}
                      readOnly
                      className="bg-muted text-muted-foreground"
                      data-testid="input-profile-cpf"
                    />
                    <p className="text-xs text-muted-foreground mt-1">CPF não pode ser alterado</p>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                  disabled={updateProfileMutation.isPending}
                  data-testid="button-update-profile"
                >
                  {updateProfileMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Atualizando...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      Salvar Alterações
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Change Password */}
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-key text-primary mr-3"></i>
                Alterar Senha de Acesso
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={passwordForm.handleSubmit(onChangePassword)} className="space-y-6">
                <div>
                  <Label>Senha Atual</Label>
                  <div className="flex space-x-2 justify-center mt-2">
                    {currentPasswordInputs.map((value, index) => (
                      <Input
                        key={`current-${index}`}
                        type="password"
                        className="w-12 h-12 text-center text-xl font-bold input-gold"
                        maxLength={1}
                        value={value}
                        onChange={(e) => handlePasswordChange('current', index, e.target.value)}
                        data-password-current-index={index}
                        data-testid={`input-current-password-${index}`}
                      />
                    ))}
                  </div>
                  {passwordForm.formState.errors.currentPassword && (
                    <p className="text-sm text-destructive mt-1 text-center">
                      {passwordForm.formState.errors.currentPassword.message}
                    </p>
                  )}
                </div>

                <Separator />

                <div>
                  <Label>Nova Senha</Label>
                  <div className="flex space-x-2 justify-center mt-2">
                    {newPasswordInputs.map((value, index) => (
                      <Input
                        key={`new-${index}`}
                        type="password"
                        className="w-12 h-12 text-center text-xl font-bold input-gold"
                        maxLength={1}
                        value={value}
                        onChange={(e) => handlePasswordChange('new', index, e.target.value)}
                        data-password-new-index={index}
                        data-testid={`input-new-password-${index}`}
                      />
                    ))}
                  </div>
                  {passwordForm.formState.errors.newPassword && (
                    <p className="text-sm text-destructive mt-1 text-center">
                      {passwordForm.formState.errors.newPassword.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label>Confirmar Nova Senha</Label>
                  <div className="flex space-x-2 justify-center mt-2">
                    {confirmPasswordInputs.map((value, index) => (
                      <Input
                        key={`confirm-${index}`}
                        type="password"
                        className="w-12 h-12 text-center text-xl font-bold input-gold"
                        maxLength={1}
                        value={value}
                        onChange={(e) => handlePasswordChange('confirm', index, e.target.value)}
                        data-password-confirm-index={index}
                        data-testid={`input-confirm-password-${index}`}
                      />
                    ))}
                  </div>
                  {passwordForm.formState.errors.confirmPassword && (
                    <p className="text-sm text-destructive mt-1 text-center">
                      {passwordForm.formState.errors.confirmPassword.message}
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                  disabled={changePasswordMutation.isPending}
                  data-testid="button-change-password"
                >
                  {changePasswordMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Alterando...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-key mr-2"></i>
                      Alterar Senha
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Account Summary */}
        <div className="space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="text-primary">Resumo da Conta</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">Status:</span>
                <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                  user?.cpf ? 'bg-green-500/10 text-green-400' : 'bg-orange-500/10 text-orange-400'
                }`}>
                  {user?.cpf ? 'Verificado' : 'Pendente'}
                </span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">Membro desde:</span>
                <span className="text-sm font-medium">
                  {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('pt-BR') : 'N/A'}
                </span>
              </div>
              
              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-sm text-muted-foreground">Tipo:</span>
                <span className="text-sm font-medium text-primary">
                  {user?.isAdmin ? 'Administrador' : 'Cliente Premium'}
                </span>
              </div>
              
              <div className="flex items-center justify-between py-2">
                <span className="text-sm text-muted-foreground">ID da Conta:</span>
                <span className="text-xs font-mono bg-muted px-2 py-1 rounded">
                  {user?.id ? user.id.substring(0, 8) : 'N/A'}...
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="text-primary">Configurações</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                data-testid="button-download-data"
              >
                <i className="fas fa-download mr-2"></i>
                Baixar Meus Dados
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start"
                data-testid="button-privacy-settings"
              >
                <i className="fas fa-shield-alt mr-2"></i>
                Configurações de Privacidade
              </Button>
              
              <Button 
                variant="outline" 
                className="w-full justify-start text-destructive hover:text-destructive"
                data-testid="button-delete-account"
              >
                <i className="fas fa-trash mr-2"></i>
                Excluir Conta
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
