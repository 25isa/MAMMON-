import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, calculateInvestmentReturn } from "@/lib/utils";

const investmentSchema = z.object({
  amount: z.string().refine((val) => {
    const num = parseFloat(val);
    return num >= 50 && num <= 5000;
  }, "Valor deve estar entre R$ 50,00 e R$ 5.000,00"),
});

type InvestmentForm = z.infer<typeof investmentSchema>;

const investmentTiers = [
  { investment: 50, return: 150, profit: 100 },
  { investment: 100, return: 300, profit: 200 },
  { investment: 200, return: 600, profit: 400 },
  { investment: 300, return: 900, profit: 600 },
  { investment: 400, return: 1200, profit: 800 },
  { investment: 500, return: 1500, profit: 1000 },
  { investment: 1000, return: 3000, profit: 2000 },
  { investment: 2000, return: 6000, profit: 4000 },
  { investment: 3000, return: 9000, profit: 6000 },
  { investment: 5000, return: 15000, profit: 10000 },
];

export default function PlanoMammonTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedAmount, setSelectedAmount] = useState<number>(0);

  const form = useForm<InvestmentForm>({
    resolver: zodResolver(investmentSchema),
    defaultValues: {
      amount: "",
    },
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: investmentPlans } = useQuery({
    queryKey: ["/api/investment-plans"],
  });

  const createInvestmentMutation = useMutation({
    mutationFn: async (data: { amount: string }) => {
      const plan = investmentPlans?.[0]; // Get the first (and likely only) plan
      if (!plan) throw new Error("No investment plans available");
      
      return await apiRequest("POST", "/api/investments", {
        planId: plan.id,
        amount: data.amount,
      });
    },
    onSuccess: () => {
      toast({
        title: "Investimento realizado com sucesso!",
        description: "Seu investimento foi processado e está ativo.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/investments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      form.reset();
      setSelectedAmount(0);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro no investimento",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAmountChange = (value: string) => {
    const numValue = parseFloat(value) || 0;
    setSelectedAmount(numValue);
    form.setValue("amount", value);
  };

  const handleTierInvestment = (amount: number) => {
    form.setValue("amount", amount.toString());
    setSelectedAmount(amount);
  };

  const onSubmit = (data: InvestmentForm) => {
    if (!user?.cpf) {
      toast({
        title: "Cadastro incompleto",
        description: "Complete seu cadastro antes de investir.",
        variant: "destructive",
      });
      return;
    }

    const userBalance = parseFloat(user.balance || "0");
    const investmentAmount = parseFloat(data.amount);

    if (userBalance < investmentAmount) {
      toast({
        title: "Saldo insuficiente",
        description: "Você não possui saldo suficiente para este investimento.",
        variant: "destructive",
      });
      return;
    }

    createInvestmentMutation.mutate(data);
  };

  const { principal, total, profit } = calculateInvestmentReturn(selectedAmount);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-crown text-primary text-3xl"></i>
        </div>
        <h2 className="text-3xl font-bold mb-2">
          Plano <span className="text-primary">MAMMON</span> Premium
        </h2>
        <p className="text-muted-foreground">Rendimento exclusivo de 200% em apenas 3 dias corridos</p>
        <div className="flex items-center justify-center space-x-2 mt-4">
          <div className="w-2 h-2 bg-primary rounded-full"></div>
          <span className="text-sm text-primary font-medium">PLANO EXCLUSIVO</span>
          <div className="w-2 h-2 bg-primary rounded-full"></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Investment Plans Table */}
        <div className="lg:col-span-2">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-table text-primary mr-3"></i>
                Tabela de Investimentos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-4 px-4 font-semibold text-primary">Valor Investido</th>
                      <th className="text-left py-4 px-4 font-semibold text-primary">Retorno (200%)</th>
                      <th className="text-left py-4 px-4 font-semibold text-primary">Lucro Líquido</th>
                      <th className="text-center py-4 px-4 font-semibold text-primary">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {investmentTiers.map((tier, index) => (
                      <tr key={index} className="hover:bg-muted/30 transition-colors" data-testid={`tier-${index}`}>
                        <td className="py-4 px-4 font-medium">{formatCurrency(tier.investment)}</td>
                        <td className="py-4 px-4 text-green-400 font-bold">{formatCurrency(tier.return)}</td>
                        <td className="py-4 px-4 text-primary font-semibold">{formatCurrency(tier.profit)}</td>
                        <td className="py-4 px-4 text-center">
                          <Button
                            size="sm"
                            className="bg-primary hover:bg-primary/90 text-primary-foreground"
                            onClick={() => handleTierInvestment(tier.investment)}
                            data-testid={`button-invest-${tier.investment}`}
                          >
                            Investir
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Investment Form and Benefits */}
        <div className="space-y-6">
          {/* Investment Form */}
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center">
                <i className="fas fa-rocket text-primary mr-3"></i>
                Fazer Investimento
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <Label>Valor do Investimento</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">R$</span>
                    <Input
                      type="number"
                      placeholder="0,00"
                      min="50"
                      max="5000"
                      step="0.01"
                      className="pl-10 input-gold"
                      value={form.watch("amount")}
                      onChange={(e) => handleAmountChange(e.target.value)}
                      data-testid="input-investment-amount"
                    />
                  </div>
                  {form.formState.errors.amount && (
                    <p className="text-sm text-destructive mt-1">
                      {form.formState.errors.amount.message}
                    </p>
                  )}
                </div>

                <div className="bg-muted/30 rounded-lg p-4 space-y-2" data-testid="investment-summary">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Valor Investido:</span>
                    <span className="font-medium" data-testid="text-principal">
                      {formatCurrency(principal)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Retorno (200%):</span>
                    <span className="font-bold text-green-400" data-testid="text-return">
                      {formatCurrency(total)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm border-t border-border pt-2">
                    <span className="text-muted-foreground">Lucro Líquido:</span>
                    <span className="font-bold text-primary" data-testid="text-profit">
                      {formatCurrency(profit)}
                    </span>
                  </div>
                </div>

                <div className="text-center text-sm text-muted-foreground space-y-1">
                  <p><i className="fas fa-clock text-primary mr-1"></i> Prazo: 3 dias corridos</p>
                  <p><i className="fas fa-chart-line text-primary mr-1"></i> Rentabilidade: 200%</p>
                  <p><i className="fas fa-shield-check text-primary mr-1"></i> Garantido</p>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-4"
                  disabled={createInvestmentMutation.isPending || selectedAmount < 50}
                  data-testid="button-submit-investment"
                >
                  {createInvestmentMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Processando...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-chart-line mr-2"></i>
                      Investir Agora
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Plan Benefits */}
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="text-primary">Vantagens Exclusivas</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-sm">
                <li className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-400"></i>
                  <span>200% de retorno garantido</span>
                </li>
                <li className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-400"></i>
                  <span>Prazo de apenas 3 dias</span>
                </li>
                <li className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-400"></i>
                  <span>Saque automático no vencimento</span>
                </li>
                <li className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-400"></i>
                  <span>Suporte 24/7 exclusivo</span>
                </li>
                <li className="flex items-center space-x-2">
                  <i className="fas fa-check-circle text-green-400"></i>
                  <span>Reinvestimento automático</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
