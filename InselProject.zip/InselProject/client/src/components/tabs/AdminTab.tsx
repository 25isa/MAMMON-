import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, isUnauthorizedError } from "@/lib/utils";
import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";

export default function AdminTab() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: allUsers = [], isLoading: loadingUsers } = useQuery({
    queryKey: ["/api/admin/users"],
    retry: false,
  });

  const { data: allInvestments = [], isLoading: loadingInvestments } = useQuery({
    queryKey: ["/api/admin/investments"],
    retry: false,
  });

  const { data: allTransactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["/api/admin/transactions"],
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Check if user is admin
  if (!user?.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <i className="fas fa-shield-alt text-red-400 text-4xl mb-4"></i>
          <h3 className="text-lg font-semibold mb-2">Acesso Negado</h3>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta área.</p>
        </div>
      </div>
    );
  }

  const getUserBadge = (user: any) => {
    if (user.isAdmin) {
      return <Badge className="bg-red-500/10 text-red-400">Admin</Badge>;
    }
    if (user.cpf) {
      return <Badge className="bg-green-500/10 text-green-400">Verificado</Badge>;
    }
    return <Badge className="bg-orange-500/10 text-orange-400">Pendente</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: "Ativo", className: "bg-green-500/10 text-green-400" },
      pending: { label: "Pendente", className: "bg-orange-500/10 text-orange-400" },
      completed: { label: "Finalizado", className: "bg-primary/10 text-primary" },
      cancelled: { label: "Cancelado", className: "bg-red-500/10 text-red-400" },
      failed: { label: "Falhou", className: "bg-red-500/10 text-red-400" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    
    return (
      <Badge className={`text-xs ${config.className}`}>
        {config.label}
      </Badge>
    );
  };

  // Calculate admin statistics
  const totalUsers = allUsers.length;
  const verifiedUsers = allUsers.filter((u: any) => u.cpf).length;
  const totalInvestments = allInvestments.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount || "0"), 0);
  const totalReturns = allInvestments.reduce((sum: number, inv: any) => sum + parseFloat(inv.expectedReturn || "0"), 0);
  const activeInvestments = allInvestments.filter((inv: any) => inv.status === "active").length;
  const completedTransactions = allTransactions.filter((txn: any) => txn.status === "completed");
  const totalDeposits = completedTransactions
    .filter((txn: any) => txn.type === "deposit")
    .reduce((sum: number, txn: any) => sum + parseFloat(txn.amount || "0"), 0);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          Painel <span className="text-primary">Administrativo</span>
        </h2>
        <p className="text-muted-foreground">Gestão completa da plataforma MAMMON Investimentos</p>
      </div>

      {/* Admin Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border premium-shadow" data-testid="card-total-users">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-users text-primary text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
                {verifiedUsers} verificados
              </span>
            </div>
            <h3 className="text-2xl font-bold text-foreground" data-testid="text-total-users">
              {totalUsers}
            </h3>
            <p className="text-sm text-muted-foreground">Total de Usuários</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-volume">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-green-400 text-xl"></i>
              </div>
              <span className="text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">
                {activeInvestments} ativos
              </span>
            </div>
            <h3 className="text-2xl font-bold text-green-400" data-testid="text-total-volume">
              {formatCurrency(totalInvestments)}
            </h3>
            <p className="text-sm text-muted-foreground">Volume Investido</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-deposits">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-wallet text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-total-platform-deposits">
              {formatCurrency(totalDeposits)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Depositado</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-expected-returns">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-trophy text-primary text-xl"></i>
              </div>
              <span className="text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">200%</span>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-total-expected-returns">
              {formatCurrency(totalReturns)}
            </h3>
            <p className="text-sm text-muted-foreground">Retornos Esperados</p>
          </CardContent>
        </Card>
      </div>

      {/* Admin Tabs */}
      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="users" data-testid="admin-tab-users">
            <i className="fas fa-users mr-2"></i>
            Usuários
          </TabsTrigger>
          <TabsTrigger value="investments" data-testid="admin-tab-investments">
            <i className="fas fa-chart-pie mr-2"></i>
            Investimentos
          </TabsTrigger>
          <TabsTrigger value="transactions" data-testid="admin-tab-transactions">
            <i className="fas fa-exchange-alt mr-2"></i>
            Transações
          </TabsTrigger>
          <TabsTrigger value="settings" data-testid="admin-tab-settings">
            <i className="fas fa-cog mr-2"></i>
            Configurações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <i className="fas fa-users text-primary mr-3"></i>
                  Gestão de Usuários ({totalUsers})
                </span>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <i className="fas fa-user-plus mr-2"></i>
                  Novo Usuário
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingUsers ? (
                <div className="flex items-center justify-center py-12">
                  <i className="fas fa-spinner fa-spin text-primary text-2xl"></i>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-2 font-semibold text-primary">Nome</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Email</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">CPF</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Saldo</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Status</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Cadastro</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {allUsers.map((user: any, index: number) => (
                        <tr key={user.id} className="hover:bg-muted/30 transition-colors" data-testid={`admin-user-row-${index}`}>
                          <td className="py-3 px-2 text-sm">
                            <div className="font-medium">{user.fullName || user.firstName || 'N/A'}</div>
                            <div className="text-xs text-muted-foreground">ID: {user.id.substring(0, 8)}...</div>
                          </td>
                          <td className="py-3 px-2 text-sm">{user.email || 'N/A'}</td>
                          <td className="py-3 px-2 text-sm font-mono">{user.cpf || 'N/A'}</td>
                          <td className="py-3 px-2 text-sm font-semibold text-primary">
                            {formatCurrency(parseFloat(user.balance || "0"))}
                          </td>
                          <td className="py-3 px-2">{getUserBadge(user)}</td>
                          <td className="py-3 px-2 text-sm">
                            {new Date(user.createdAt).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" data-testid={`button-edit-user-${index}`}>
                                <i className="fas fa-edit text-xs"></i>
                              </Button>
                              <Button size="sm" variant="outline" data-testid={`button-view-user-${index}`}>
                                <i className="fas fa-eye text-xs"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="investments" className="space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <i className="fas fa-chart-pie text-primary mr-3"></i>
                  Gestão de Investimentos ({allInvestments.length})
                </span>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <i className="fas fa-filter mr-2"></i>
                    Filtrar
                  </Button>
                  <Button size="sm" className="bg-primary hover:bg-primary/90">
                    <i className="fas fa-download mr-2"></i>
                    Exportar
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingInvestments ? (
                <div className="flex items-center justify-center py-12">
                  <i className="fas fa-spinner fa-spin text-primary text-2xl"></i>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-2 font-semibold text-primary">Usuário</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Valor</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Retorno Esperado</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Status</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Data</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Vencimento</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {allInvestments.map((investment: any, index: number) => (
                        <tr key={investment.id} className="hover:bg-muted/30 transition-colors" data-testid={`admin-investment-row-${index}`}>
                          <td className="py-3 px-2 text-sm">
                            <div className="text-xs text-muted-foreground">ID: {investment.userId.substring(0, 8)}...</div>
                          </td>
                          <td className="py-3 px-2 text-sm font-semibold">
                            {formatCurrency(parseFloat(investment.amount))}
                          </td>
                          <td className="py-3 px-2 text-sm font-semibold text-green-400">
                            {formatCurrency(parseFloat(investment.expectedReturn))}
                          </td>
                          <td className="py-3 px-2">{getStatusBadge(investment.status)}</td>
                          <td className="py-3 px-2 text-sm">
                            {new Date(investment.createdAt).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="py-3 px-2 text-sm">
                            {investment.maturityDate ? 
                              new Date(investment.maturityDate).toLocaleDateString('pt-BR') : 'N/A'}
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" data-testid={`button-process-investment-${index}`}>
                                <i className="fas fa-check text-xs"></i>
                              </Button>
                              <Button size="sm" variant="outline" data-testid={`button-view-investment-${index}`}>
                                <i className="fas fa-eye text-xs"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <i className="fas fa-exchange-alt text-primary mr-3"></i>
                  Gestão de Transações ({allTransactions.length})
                </span>
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  <i className="fas fa-sync-alt mr-2"></i>
                  Atualizar
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="flex items-center justify-center py-12">
                  <i className="fas fa-spinner fa-spin text-primary text-2xl"></i>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-2 font-semibold text-primary">Usuário</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Tipo</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Valor</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Status</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Data</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Descrição</th>
                        <th className="text-left py-3 px-2 font-semibold text-primary">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {allTransactions.slice(0, 50).map((transaction: any, index: number) => (
                        <tr key={transaction.id} className="hover:bg-muted/30 transition-colors" data-testid={`admin-transaction-row-${index}`}>
                          <td className="py-3 px-2 text-sm">
                            <div className="text-xs text-muted-foreground">ID: {transaction.userId.substring(0, 8)}...</div>
                          </td>
                          <td className="py-3 px-2 text-sm">
                            <Badge className={`text-xs ${
                              transaction.type === 'deposit' ? 'bg-green-500/10 text-green-400' :
                              transaction.type === 'withdrawal' ? 'bg-orange-500/10 text-orange-400' :
                              transaction.type === 'investment' ? 'bg-blue-500/10 text-blue-400' :
                              'bg-primary/10 text-primary'
                            }`}>
                              {transaction.type}
                            </Badge>
                          </td>
                          <td className={`py-3 px-2 text-sm font-semibold ${
                            transaction.type === 'deposit' || transaction.type === 'return' ? 'text-green-400' : 'text-orange-400'
                          }`}>
                            {transaction.type === 'deposit' || transaction.type === 'return' ? '+' : '-'}
                            {formatCurrency(parseFloat(transaction.amount))}
                          </td>
                          <td className="py-3 px-2">{getStatusBadge(transaction.status)}</td>
                          <td className="py-3 px-2 text-sm">
                            {new Date(transaction.createdAt).toLocaleDateString('pt-BR')}
                          </td>
                          <td className="py-3 px-2 text-sm text-muted-foreground max-w-[200px] truncate">
                            {transaction.description || 'N/A'}
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" data-testid={`button-approve-transaction-${index}`}>
                                <i className="fas fa-check text-xs"></i>
                              </Button>
                              <Button size="sm" variant="outline" data-testid={`button-view-transaction-${index}`}>
                                <i className="fas fa-eye text-xs"></i>
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-card border-border premium-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-cog text-primary mr-3"></i>
                  Configurações da Plataforma
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full justify-start" variant="outline" data-testid="button-platform-settings">
                  <i className="fas fa-sliders-h mr-2"></i>
                  Configurações Gerais
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-investment-plans">
                  <i className="fas fa-chart-line mr-2"></i>
                  Planos de Investimento
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-payment-methods">
                  <i className="fas fa-credit-card mr-2"></i>
                  Métodos de Pagamento
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-security-settings">
                  <i className="fas fa-shield-alt mr-2"></i>
                  Configurações de Segurança
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-card border-border premium-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <i className="fas fa-tools text-primary mr-3"></i>
                  Ferramentas de Administração
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full justify-start" variant="outline" data-testid="button-backup-data">
                  <i className="fas fa-database mr-2"></i>
                  Backup de Dados
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-system-logs">
                  <i className="fas fa-list-alt mr-2"></i>
                  Logs do Sistema
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-send-notifications">
                  <i className="fas fa-bell mr-2"></i>
                  Enviar Notificações
                </Button>
                <Button className="w-full justify-start" variant="outline" data-testid="button-maintenance-mode">
                  <i className="fas fa-wrench mr-2"></i>
                  Modo Manutenção
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
