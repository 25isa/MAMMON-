import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCurrency, isUnauthorizedError } from "@/lib/utils";

const transactionSchema = z.object({
  type: z.enum(["deposit", "withdrawal"]),
  amount: z.string().refine((val) => {
    const num = parseFloat(val);
    return num > 0 && num <= 50000;
  }, "Valor deve ser entre R$ 0,01 e R$ 50.000,00"),
  description: z.string().optional(),
});

type TransactionForm = z.infer<typeof transactionSchema>;

const paymentMethods = [
  { id: "pix", name: "PIX", icon: "fas fa-qrcode" },
  { id: "bank_transfer", name: "Transferência Bancária", icon: "fas fa-university" },
  { id: "credit_card", name: "Cartão de Crédito", icon: "fas fa-credit-card" },
  { id: "debit_card", name: "Cartão de Débito", icon: "fas fa-credit-card" },
];

export default function FinanceiroTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMethod, setSelectedMethod] = useState<string>("pix");
  const [activeTab, setActiveTab] = useState<string>("deposit");
  const [mainTab, setMainTab] = useState<string>("transactions");

  const form = useForm<TransactionForm>({
    resolver: zodResolver(transactionSchema),
    defaultValues: {
      type: "deposit",
      amount: "",
      description: "",
    },
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const { data: transactions = [], isLoading: loadingTransactions } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const createTransactionMutation = useMutation({
    mutationFn: async (data: TransactionForm) => {
      return await apiRequest("POST", "/api/transactions", {
        ...data,
        description: data.description || `${data.type === 'deposit' ? 'Depósito' : 'Saque'} via ${selectedMethod}`,
      });
    },
    onSuccess: () => {
      toast({
        title: activeTab === "deposit" ? "Depósito realizado!" : "Saque solicitado!",
        description: activeTab === "deposit" 
          ? "Seu depósito foi processado com sucesso." 
          : "Sua solicitação de saque está sendo processada.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      form.reset();
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Erro na transação",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleTabChange = (value: string) => {
    setActiveTab(value);
    form.setValue("type", value as "deposit" | "withdrawal");
    form.reset({
      type: value as "deposit" | "withdrawal",
      amount: "",
      description: "",
    });
  };

  const onSubmit = (data: TransactionForm) => {
    if (data.type === "withdrawal") {
      const userBalance = parseFloat((user as any)?.balance || "0");
      const withdrawalAmount = parseFloat(data.amount);
      
      if (userBalance < withdrawalAmount) {
        toast({
          title: "Saldo insuficiente",
          description: "Você não possui saldo suficiente para este saque.",
          variant: "destructive",
        });
        return;
      }
    }

    createTransactionMutation.mutate(data);
  };

  const getTransactionBadge = (type: string, status: string) => {
    const typeConfig = {
      deposit: { label: "Depósito", className: "bg-green-500/10 text-green-400" },
      withdrawal: { label: "Saque", className: "bg-orange-500/10 text-orange-400" },
      investment: { label: "Investimento", className: "bg-blue-500/10 text-blue-400" },
      return: { label: "Retorno", className: "bg-primary/10 text-primary" },
      profit: { label: "Lucro", className: "bg-emerald-500/10 text-emerald-400" },
    };

    const statusConfig = {
      completed: { label: "Concluído", className: "bg-green-500/10 text-green-400" },
      pending: { label: "Pendente", className: "bg-orange-500/10 text-orange-400" },
      failed: { label: "Falhou", className: "bg-red-500/10 text-red-400" },
    };

    const typeInfo = typeConfig[type as keyof typeof typeConfig] || typeConfig.deposit;
    const statusInfo = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

    return (
      <div className="flex space-x-2">
        <Badge className={`text-xs ${typeInfo.className}`}>
          {typeInfo.label}
        </Badge>
        <Badge className={`text-xs ${statusInfo.className}`}>
          {statusInfo.label}
        </Badge>
      </div>
    );
  };

  const balance = (user as any)?.balance ? parseFloat((user as any).balance) : 0;
  const completedTransactions = (transactions as any[]).filter((t: any) => t.status === "completed");
  const totalDeposits = completedTransactions
    .filter((t: any) => t.type === "deposit")
    .reduce((sum: number, t: any) => sum + parseFloat(t.amount || "0"), 0);
  const totalWithdrawals = completedTransactions
    .filter((t: any) => t.type === "withdrawal")
    .reduce((sum: number, t: any) => sum + parseFloat(t.amount || "0"), 0);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          Central <span className="text-primary">Financeira</span>
        </h2>
        <p className="text-muted-foreground">Gerencie seus depósitos, saques e transações</p>
      </div>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-card border-border premium-shadow" data-testid="card-current-balance">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-wallet text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-current-balance">
              {formatCurrency(balance)}
            </h3>
            <p className="text-sm text-muted-foreground">Saldo Atual</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-deposits">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-arrow-down text-green-400 text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-green-400" data-testid="text-total-deposits">
              {formatCurrency(totalDeposits)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Depositado</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-withdrawals">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-500/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-arrow-up text-orange-400 text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-orange-400" data-testid="text-total-withdrawals">
              {formatCurrency(totalWithdrawals)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Sacado</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-net-flow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-foreground" data-testid="text-net-flow">
              {formatCurrency(totalDeposits - totalWithdrawals)}
            </h3>
            <p className="text-sm text-muted-foreground">Fluxo Líquido</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Navigation Tabs */}
      <Tabs value={mainTab} onValueChange={setMainTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 bg-muted/30 p-2 h-14">
          <TabsTrigger 
            value="transactions" 
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-bold text-base"
          >
            <i className="fas fa-exchange-alt mr-2"></i>
            Nova Transação
          </TabsTrigger>
          <TabsTrigger 
            value="history" 
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground font-bold text-base"
          >
            <i className="fas fa-history mr-2"></i>
            Histórico
          </TabsTrigger>
        </TabsList>

        <TabsContent value="transactions">
          {/* Transaction Form - Now Full Width */}
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              <div className="absolute -top-2 -left-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-bold z-10 animate-bounce">
                <i className="fas fa-star mr-2"></i>
                TRANSAÇÃO RÁPIDA
              </div>
              <Card className="bg-gradient-to-br from-primary/15 to-primary/5 border-2 border-primary/40 premium-shadow-lg hover:border-primary/60 transition-all duration-300">
                <CardHeader className="bg-primary/20 rounded-t-lg border-b border-primary/20">
                  <CardTitle className="flex items-center text-2xl font-bold">
                    <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-4">
                      <i className="fas fa-plus text-primary-foreground text-xl"></i>
                    </div>
                    <div>
                      <span className="text-primary">Nova Transação</span>
                      <p className="text-sm text-muted-foreground font-normal mt-1">
                        Faça depósitos e saques de forma rápida e segura
                      </p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <Tabs value={activeTab} onValueChange={handleTabChange}>
                    <TabsList className="grid w-full grid-cols-2 bg-muted/30 p-2 h-16 mb-8">
                      <TabsTrigger 
                        value="deposit" 
                        data-testid="tab-deposit"
                        className="data-[state=active]:bg-green-500 data-[state=active]:text-white font-bold text-lg py-4"
                      >
                        <i className="fas fa-arrow-down mr-3 text-xl"></i>
                        Depósito
                      </TabsTrigger>
                      <TabsTrigger 
                        value="withdrawal" 
                        data-testid="tab-withdrawal"
                        className="data-[state=active]:bg-orange-500 data-[state=active]:text-white font-bold text-lg py-4"
                      >
                        <i className="fas fa-arrow-up mr-3 text-xl"></i>
                        Saque
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="deposit" className="space-y-6 mt-8">
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {/* PIX Payment Section */}
                        {selectedMethod === "pix" && (
                          <div className="lg:col-span-2">
                            <div className="bg-primary/5 border border-primary/20 rounded-lg p-6 mb-6">
                              <h4 className="font-bold text-primary mb-4 flex items-center text-lg">
                                <i className="fas fa-qrcode mr-3 text-xl"></i>
                                Pagamento via PIX - MAMMON INVESTIMENTOS
                              </h4>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                  <h5 className="text-base font-semibold mb-3">QR Code PIX:</h5>
                                  <div className="bg-white p-4 rounded-lg flex items-center justify-center">
                                    <img 
                                      src="/attached_assets/qrcode-pix (2)_1756945764155_1757042828931.png" 
                                      alt="QR Code PIX MAMMON"
                                      className="w-40 h-40 object-contain"
                                      data-testid="img-pix-qrcode"
                                    />
                                  </div>
                                  <p className="text-sm text-muted-foreground mt-3 text-center">
                                    Escaneie com seu app do banco
                                  </p>
                                </div>
                                
                                <div>
                                  <h5 className="text-base font-semibold mb-3">Código PIX Copia e Cola:</h5>
                                  <div className="bg-muted/20 p-4 rounded-lg">
                                    <code className="text-sm break-all text-foreground">
                                      00020126580014BR.GOV.BCB.PIX01360e770275-52ee-4486-b297-4264e6b3ced15204000053039865802BR5901N6001C62100506MAMMON63042FDF
                                    </code>
                                  </div>
                                  <Button 
                                    type="button"
                                    variant="outline"
                                    className="w-full mt-3 text-primary border-primary hover:bg-primary/10 py-3"
                                    onClick={() => {
                                      navigator.clipboard.writeText("00020126580014BR.GOV.BCB.PIX01360e770275-52ee-4486-b297-4264e6b3ced15204000053039865802BR5901N6001C62100506MAMMON63042FDF");
                                      toast({
                                        title: "Código PIX copiado!",
                                        description: "Cole no seu app do banco para fazer o pagamento.",
                                      });
                                    }}
                                    data-testid="button-copy-pix"
                                  >
                                    <i className="fas fa-copy mr-2"></i>
                                    Copiar Código PIX
                                  </Button>
                                  
                                  <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 rounded text-sm text-green-400">
                                    <i className="fas fa-info-circle mr-2"></i>
                                    <strong>Favorecido:</strong> MAMMON<br/>
                                    <strong>Instituição:</strong> Banco Central do Brasil
                                  </div>
                                </div>
                              </div>
                              
                              <div className="mt-6 p-4 bg-orange-500/10 border border-orange-500/20 rounded text-orange-400">
                                <i className="fas fa-exclamation-triangle mr-2"></i>
                                <strong>Importante:</strong> Após realizar o pagamento PIX, clique em "Confirmar Depósito" abaixo para registrar sua transação.
                              </div>
                            </div>
                          </div>
                        )}
                        
                        <form onSubmit={form.handleSubmit(onSubmit)} className="lg:col-span-2 space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                              <Label className="text-base font-semibold">Valor do Depósito</Label>
                              <div className="relative mt-2">
                                <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground text-lg">R$</span>
                                <Input
                                  type="number"
                                  placeholder="0,00"
                                  step="0.01"
                                  min="0.01"
                                  max="50000"
                                  className="pl-12 input-gold h-14 text-lg"
                                  {...form.register("amount")}
                                  data-testid="input-deposit-amount"
                                />
                              </div>
                              {form.formState.errors.amount && (
                                <p className="text-sm text-destructive mt-2">
                                  {form.formState.errors.amount.message}
                                </p>
                              )}
                            </div>

                            <div>
                              <Label className="text-base font-semibold">Método de Pagamento</Label>
                              <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                                <SelectTrigger className="input-gold h-14 text-lg mt-2" data-testid="select-payment-method">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {paymentMethods.map((method) => (
                                    <SelectItem key={method.id} value={method.id}>
                                      <div className="flex items-center space-x-3">
                                        <i className={`${method.icon} text-primary text-lg`}></i>
                                        <span>{method.name}</span>
                                      </div>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          <div>
                            <Label className="text-base font-semibold">Observações (Opcional)</Label>
                            <Input
                              placeholder="Adicione uma observação..."
                              className="input-gold h-14 text-lg mt-2"
                              {...form.register("description")}
                              data-testid="input-transaction-description"
                            />
                          </div>

                          <Button
                            type="submit"
                            className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold text-xl py-8 shadow-lg hover:shadow-xl transition-all duration-200 animate-pulse mt-8"
                            disabled={createTransactionMutation.isPending}
                            data-testid="button-submit-deposit"
                          >
                            {createTransactionMutation.isPending ? (
                              <>
                                <i className="fas fa-spinner fa-spin mr-3 text-2xl"></i>
                                Processando Transação...
                              </>
                            ) : selectedMethod === "pix" ? (
                              <>
                                <i className="fas fa-check-circle mr-3 text-2xl"></i>
                                Confirmar Depósito PIX
                              </>
                            ) : (
                              <>
                                <i className="fas fa-plus-circle mr-3 text-2xl"></i>
                                Realizar Depósito
                              </>
                            )}
                          </Button>
                        </form>
                      </div>
                    </TabsContent>

                <TabsContent value="withdrawal" className="space-y-4 mt-6">
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="bg-orange-500/10 border border-orange-500/20 rounded-lg p-3 text-sm text-orange-400">
                      <i className="fas fa-info-circle mr-2"></i>
                      Saldo disponível: {formatCurrency(balance)}
                    </div>

                    <div>
                      <Label>Valor do Saque</Label>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">R$</span>
                        <Input
                          type="number"
                          placeholder="0,00"
                          step="0.01"
                          min="0.01"
                          max={balance.toString()}
                          className="pl-10 input-gold"
                          {...form.register("amount")}
                          data-testid="input-withdrawal-amount"
                        />
                      </div>
                      {form.formState.errors.amount && (
                        <p className="text-sm text-destructive mt-1">
                          {form.formState.errors.amount.message}
                        </p>
                      )}
                    </div>

                    <div>
                      <Label>Método de Recebimento</Label>
                      <Select value={selectedMethod} onValueChange={setSelectedMethod}>
                        <SelectTrigger className="input-gold" data-testid="select-withdrawal-method">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {paymentMethods.slice(0, 2).map((method) => (
                            <SelectItem key={method.id} value={method.id}>
                              <div className="flex items-center space-x-2">
                                <i className={`${method.icon} text-primary`}></i>
                                <span>{method.name}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Observações (Opcional)</Label>
                      <Input
                        placeholder="Adicione uma observação..."
                        className="input-gold"
                        {...form.register("description")}
                        data-testid="input-withdrawal-description"
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold text-lg py-6 shadow-lg hover:shadow-xl transition-all duration-200"
                      disabled={createTransactionMutation.isPending || balance <= 0}
                      data-testid="button-submit-withdrawal"
                    >
                      {createTransactionMutation.isPending ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-3 text-xl"></i>
                          Processando Saque...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-arrow-up-circle mr-3 text-xl"></i>
                          Solicitar Saque
                        </>
                      )}
                    </Button>
                  </form>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle className="flex items-center text-2xl">
                <i className="fas fa-history text-primary mr-3"></i>
                Histórico de Transações ({(transactions as any[])?.length || 0})
              </CardTitle>
              <p className="text-muted-foreground mt-2">
                Visualize todas as suas transações financeiras
              </p>
            </CardHeader>
            <CardContent>
              {loadingTransactions ? (
                <div className="flex items-center justify-center py-16">
                  <div className="text-center">
                    <i className="fas fa-spinner fa-spin text-primary text-4xl mb-4"></i>
                    <p className="text-muted-foreground">Carregando transações...</p>
                  </div>
                </div>
              ) : !transactions || (transactions as any[]).length === 0 ? (
                <div className="text-center py-16">
                  <i className="fas fa-receipt text-muted-foreground text-6xl mb-6"></i>
                  <h3 className="text-xl font-semibold mb-3">Nenhuma transação encontrada</h3>
                  <p className="text-muted-foreground mb-6">Suas transações aparecerão aqui após realizar depósitos ou saques</p>
                  <Button
                    onClick={() => setMainTab("transactions")}
                    className="bg-primary hover:bg-primary/90"
                  >
                    <i className="fas fa-plus mr-2"></i>
                    Fazer Nova Transação
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b-2 border-primary/20">
                        <th className="text-left py-4 px-3 font-bold text-primary text-base">Data</th>
                        <th className="text-left py-4 px-3 font-bold text-primary text-base">Tipo</th>
                        <th className="text-left py-4 px-3 font-bold text-primary text-base">Valor</th>
                        <th className="text-left py-4 px-3 font-bold text-primary text-base">Status</th>
                        <th className="text-left py-4 px-3 font-bold text-primary text-base">Descrição</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {(transactions as any[]).map((transaction: any, index: number) => (
                        <tr 
                          key={transaction.id}
                          className="hover:bg-muted/30 transition-colors"
                          data-testid={`transaction-row-${index}`}
                        >
                          <td className="py-4 px-3 text-sm">
                            {new Date(transaction.createdAt).toLocaleDateString('pt-BR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </td>
                          <td className="py-4 px-3">
                            {getTransactionBadge(transaction.type, transaction.status)}
                          </td>
                          <td className={`py-4 px-3 text-base font-bold ${
                            transaction.type === 'deposit' || transaction.type === 'return' || transaction.type === 'profit'
                              ? 'text-green-400'
                              : 'text-orange-400'
                          }`}>
                            {transaction.type === 'deposit' || transaction.type === 'return' || transaction.type === 'profit' ? '+' : '-'}
                            {formatCurrency(parseFloat(transaction.amount))}
                          </td>
                          <td className="py-4 px-3 text-sm">
                            {transaction.status === 'completed' && <i className="fas fa-check-circle text-green-400 mr-2"></i>}
                            {transaction.status === 'pending' && <i className="fas fa-clock text-orange-400 mr-2"></i>}
                            {transaction.status === 'failed' && <i className="fas fa-times-circle text-red-400 mr-2"></i>}
                            {transaction.status === 'completed' ? 'Concluído' : 
                             transaction.status === 'pending' ? 'Pendente' : 'Falhou'}
                          </td>
                          <td className="py-4 px-3 text-sm text-muted-foreground">
                            {transaction.description || 'Sem descrição'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
