import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency, calculateInvestmentReturn, getMaturityDate } from "@/lib/utils";

const presetValues = [50, 100, 500, 1000, 5000];

const investmentComparison = [
  { investment: 50, return: 150, profit: 100 },
  { investment: 100, return: 300, profit: 200 },
  { investment: 500, return: 1500, profit: 1000 },
  { investment: 1000, return: 3000, profit: 2000 },
  { investment: 5000, return: 15000, profit: 10000 },
];

export default function CalculadoraTab() {
  const [amount, setAmount] = useState<number>(0);
  const [period, setPeriod] = useState<string>("3");
  const [results, setResults] = useState({
    principal: 0,
    total: 0,
    profit: 0,
    maturityDate: "",
  });

  const handleAmountChange = (value: string) => {
    const numValue = parseFloat(value) || 0;
    setAmount(numValue);
  };

  const handlePresetClick = (value: number) => {
    setAmount(value);
    calculateResults(value);
  };

  const calculateResults = (investmentAmount?: number) => {
    const calcAmount = investmentAmount || amount;
    const { principal, total, profit } = calculateInvestmentReturn(calcAmount);
    const maturityDate = getMaturityDate(parseInt(period));
    
    setResults({
      principal,
      total,
      profit,
      maturityDate: maturityDate.toLocaleDateString('pt-BR'),
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-calculator text-primary text-2xl"></i>
        </div>
        <h2 className="text-2xl font-bold mb-2">Calculadora de Investimentos</h2>
        <p className="text-muted-foreground">Simule seus rendimentos com o Plano Mammon</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Calculator Form */}
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle>Simulação de Investimento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label>Valor a Investir</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">R$</span>
                <Input
                  type="number"
                  placeholder="0,00"
                  min="50"
                  max="5000"
                  step="0.01"
                  className="pl-10 input-gold"
                  value={amount || ""}
                  onChange={(e) => handleAmountChange(e.target.value)}
                  data-testid="input-calc-amount"
                />
              </div>
              <div className="flex space-x-2 mt-2 flex-wrap">
                {presetValues.map((value) => (
                  <Button
                    key={value}
                    variant="outline"
                    size="sm"
                    className="text-xs hover:bg-primary hover:text-primary-foreground"
                    onClick={() => handlePresetClick(value)}
                    data-testid={`button-preset-${value}`}
                  >
                    R$ {value}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <Label>Período de Investimento</Label>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="input-gold" data-testid="select-period">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 dias (Plano Mammon)</SelectItem>
                  <SelectItem value="7">7 dias (Em breve)</SelectItem>
                  <SelectItem value="15">15 dias (Em breve)</SelectItem>
                  <SelectItem value="30">30 dias (Em breve)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Taxa de Retorno</Label>
              <div className="relative">
                <Input
                  type="number"
                  value="200"
                  readOnly
                  className="pr-8"
                  data-testid="input-return-rate"
                />
                <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">%</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Taxa fixa do Plano Mammon</p>
            </div>

            <Button
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-4"
              onClick={() => calculateResults()}
              data-testid="button-calculate"
            >
              <i className="fas fa-calculator mr-2"></i>
              Calcular Rendimento
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="space-y-6">
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle>Resultados da Simulação</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted/30 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Valor Investido:</span>
                  <span className="text-xl font-bold" data-testid="text-calc-principal">
                    {formatCurrency(results.principal)}
                  </span>
                </div>
              </div>

              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-green-400">Valor de Retorno:</span>
                  <span className="text-2xl font-bold text-green-400" data-testid="text-calc-total">
                    {formatCurrency(results.total)}
                  </span>
                </div>
              </div>

              <div className="bg-primary/10 border border-primary/20 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-primary">Lucro Líquido:</span>
                  <span className="text-2xl font-bold text-primary" data-testid="text-calc-profit">
                    {formatCurrency(results.profit)}
                  </span>
                </div>
              </div>

              <div className="bg-muted/30 rounded-lg p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Rentabilidade:</span>
                  <span className="font-medium text-primary">200%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Prazo:</span>
                  <span className="font-medium">{period} dias corridos</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Data de Vencimento:</span>
                  <span className="font-medium" data-testid="text-calc-maturity">
                    {results.maturityDate || "--/--/----"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Investment Comparison */}
          <Card className="bg-card border-border premium-shadow">
            <CardHeader>
              <CardTitle>Comparativo de Valores</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-2">Investimento</th>
                      <th className="text-right py-2">Retorno</th>
                      <th className="text-right py-2">Lucro</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border text-xs">
                    {investmentComparison.map((row, index) => (
                      <tr key={index} className={index === investmentComparison.length - 1 ? "font-bold" : ""}>
                        <td className="py-2">{formatCurrency(row.investment)}</td>
                        <td className="py-2 text-right text-green-400">{formatCurrency(row.return)}</td>
                        <td className="py-2 text-right text-primary">{formatCurrency(row.profit)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
