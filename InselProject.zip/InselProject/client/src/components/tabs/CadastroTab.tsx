import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatCPF, formatPhone, validateCPF } from "@/lib/utils";

const registrationSchema = z.object({
  fullName: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  cpf: z.string().refine(validateCPF, "CPF inválido"),
  phone: z.string().min(10, "Telefone deve ter pelo menos 10 dígitos"),
  email: z.string().email("Email inválido").optional().or(z.literal("")),
  accessPassword: z.string().length(5, "Senha deve ter exatamente 5 dígitos").regex(/^\d+$/, "Senha deve conter apenas números"),
  terms: z.boolean().refine((val) => val === true, "Você deve aceitar os termos"),
});

type RegistrationForm = z.infer<typeof registrationSchema>;

export default function CadastroTab() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [passwordInputs, setPasswordInputs] = useState<string[]>(["", "", "", "", ""]);

  const form = useForm<RegistrationForm>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      fullName: "",
      cpf: "",
      phone: "",
      email: "",
      accessPassword: "",
      terms: false,
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegistrationForm) => {
      return await apiRequest("POST", "/api/register", data);
    },
    onSuccess: () => {
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Agora você pode acessar todos os recursos da plataforma.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro no cadastro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePasswordChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return; // Only numbers
    
    const newInputs = [...passwordInputs];
    newInputs[index] = value;
    setPasswordInputs(newInputs);
    
    const password = newInputs.join("");
    form.setValue("accessPassword", password);

    // Auto-focus next input
    if (value && index < 4) {
      const nextInput = document.querySelector(`input[data-password-index="${index + 1}"]`) as HTMLInputElement;
      nextInput?.focus();
    }
  };

  const handleCpfChange = (value: string) => {
    const formatted = formatCPF(value);
    form.setValue("cpf", formatted.replace(/\D/g, "")); // Store only numbers
    return formatted;
  };

  const handlePhoneChange = (value: string) => {
    const formatted = formatPhone(value);
    form.setValue("phone", formatted.replace(/\D/g, "")); // Store only numbers
    return formatted;
  };

  const onSubmit = (data: RegistrationForm) => {
    registerMutation.mutate(data);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <Card className="bg-card border-border premium-shadow">
        <CardHeader className="text-center">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-user-plus text-primary text-2xl"></i>
          </div>
          <CardTitle className="text-2xl">Cadastro de Cliente</CardTitle>
          <CardDescription>
            Complete seus dados para acessar a plataforma premium
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="fullName">Nome Completo *</Label>
                <Input
                  id="fullName"
                  {...form.register("fullName")}
                  placeholder="Digite seu nome completo"
                  className="input-gold"
                  data-testid="input-fullname"
                />
                {form.formState.errors.fullName && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.fullName.message}
                  </p>
                )}
              </div>
              
              <div>
                <Label htmlFor="cpf">CPF *</Label>
                <Input
                  id="cpf"
                  placeholder="000.000.000-00"
                  className="input-gold"
                  onChange={(e) => {
                    e.target.value = handleCpfChange(e.target.value);
                  }}
                  maxLength={14}
                  data-testid="input-cpf"
                />
                {form.formState.errors.cpf && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.cpf.message}
                  </p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="phone">Telefone *</Label>
                <Input
                  id="phone"
                  placeholder="(11) 99999-9999"
                  className="input-gold"
                  onChange={(e) => {
                    e.target.value = handlePhoneChange(e.target.value);
                  }}
                  maxLength={15}
                  data-testid="input-phone"
                />
                {form.formState.errors.phone && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.phone.message}
                  </p>
                )}
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...form.register("email")}
                  placeholder="seu@email.com"
                  className="input-gold"
                  data-testid="input-email"
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive mt-1">
                    {form.formState.errors.email.message}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label>Senha de Acesso (5 dígitos) *</Label>
              <div className="flex space-x-3 justify-center mt-2">
                {passwordInputs.map((value, index) => (
                  <Input
                    key={index}
                    type="password"
                    className="w-12 h-12 text-center text-xl font-bold input-gold"
                    maxLength={1}
                    value={value}
                    onChange={(e) => handlePasswordChange(index, e.target.value)}
                    data-password-index={index}
                    data-testid={`input-password-${index}`}
                  />
                ))}
              </div>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Use apenas números para sua senha de acesso
              </p>
              {form.formState.errors.accessPassword && (
                <p className="text-sm text-destructive mt-1 text-center">
                  {form.formState.errors.accessPassword.message}
                </p>
              )}
            </div>

            <div className="flex items-center space-x-3">
              <Checkbox
                id="terms"
                checked={form.watch("terms")}
                onCheckedChange={(checked) => form.setValue("terms", checked as boolean)}
                data-testid="checkbox-terms"
              />
              <Label htmlFor="terms" className="text-sm text-muted-foreground">
                Aceito os{" "}
                <a href="#" className="text-primary hover:underline">
                  termos de uso
                </a>{" "}
                e{" "}
                <a href="#" className="text-primary hover:underline">
                  política de privacidade
                </a>
              </Label>
            </div>
            {form.formState.errors.terms && (
              <p className="text-sm text-destructive">
                {form.formState.errors.terms.message}
              </p>
            )}

            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-4"
              disabled={registerMutation.isPending}
              data-testid="button-register"
            >
              {registerMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Cadastrando...
                </>
              ) : (
                <>
                  <i className="fas fa-user-check mr-2"></i>
                  Cadastrar Cliente
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
