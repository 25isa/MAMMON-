import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DatePickerWithRange } from "@/components/ui/date-picker";
import { formatCurrency } from "@/lib/utils";
import { useState } from "react";
import { DateRange } from "react-day-picker";
import { addDays, subDays, subMonths, startOfMonth, endOfMonth } from "date-fns";

export default function RelatoriosTab() {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });
  const [reportType, setReportType] = useState<string>("all");

  const { data: investments = [] } = useQuery({
    queryKey: ["/api/investments"],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  const handlePredefinedRange = (range: string) => {
    const now = new Date();
    let from: Date;
    let to: Date = now;

    switch (range) {
      case "today":
        from = now;
        break;
      case "week":
        from = subDays(now, 7);
        break;
      case "month":
        from = subDays(now, 30);
        break;
      case "3months":
        from = subMonths(now, 3);
        break;
      case "current_month":
        from = startOfMonth(now);
        to = endOfMonth(now);
        break;
      default:
        from = subDays(now, 30);
    }

    setDateRange({ from, to });
  };

  const generateReport = () => {
    // In a real application, this would trigger a report generation
    console.log("Generating report:", { dateRange, reportType });
  };

  const downloadReport = (format: string) => {
    // In a real application, this would download the report in the specified format
    console.log("Downloading report in format:", format);
  };

  // Filter data based on date range
  const filteredInvestments = investments.filter((inv: any) => {
    if (!dateRange?.from || !dateRange?.to) return true;
    const investmentDate = new Date(inv.createdAt);
    return investmentDate >= dateRange.from && investmentDate <= dateRange.to;
  });

  const filteredTransactions = transactions.filter((txn: any) => {
    if (!dateRange?.from || !dateRange?.to) return true;
    const transactionDate = new Date(txn.createdAt);
    return transactionDate >= dateRange.from && transactionDate <= dateRange.to;
  });

  // Calculate metrics
  const totalInvested = filteredInvestments.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount || "0"), 0);
  const totalExpectedReturns = filteredInvestments.reduce((sum: number, inv: any) => sum + parseFloat(inv.expectedReturn || "0"), 0);
  const totalProfit = totalExpectedReturns - totalInvested;
  const activeInvestments = filteredInvestments.filter((inv: any) => inv.status === "active").length;
  const completedInvestments = filteredInvestments.filter((inv: any) => inv.status === "completed").length;

  const deposits = filteredTransactions.filter((txn: any) => txn.type === "deposit");
  const withdrawals = filteredTransactions.filter((txn: any) => txn.type === "withdrawal");
  const totalDeposits = deposits.reduce((sum: number, txn: any) => sum + parseFloat(txn.amount || "0"), 0);
  const totalWithdrawals = withdrawals.reduce((sum: number, txn: any) => sum + parseFloat(txn.amount || "0"), 0);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          <span className="text-primary">Relatórios</span> e Análises
        </h2>
        <p className="text-muted-foreground">Análise completa do seu desempenho e histórico financeiro</p>
      </div>

      {/* Report Configuration */}
      <Card className="bg-card border-border premium-shadow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-cog text-primary mr-3"></i>
            Configurações do Relatório
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Período</label>
              <DatePickerWithRange
                date={dateRange}
                onDateChange={setDateRange}
                data-testid="date-range-picker"
              />
              <div className="flex flex-wrap gap-2 mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePredefinedRange("today")}
                  data-testid="button-range-today"
                >
                  Hoje
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePredefinedRange("week")}
                  data-testid="button-range-week"
                >
                  7 dias
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePredefinedRange("month")}
                  data-testid="button-range-month"
                >
                  30 dias
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePredefinedRange("current_month")}
                  data-testid="button-range-current-month"
                >
                  Mês atual
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Tipo de Relatório</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger data-testid="select-report-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Relatório Completo</SelectItem>
                  <SelectItem value="investments">Apenas Investimentos</SelectItem>
                  <SelectItem value="transactions">Apenas Transações</SelectItem>
                  <SelectItem value="performance">Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col justify-end space-y-2">
              <Button
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={generateReport}
                data-testid="button-generate-report"
              >
                <i className="fas fa-chart-bar mr-2"></i>
                Gerar Relatório
              </Button>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => downloadReport("pdf")}
                  data-testid="button-download-pdf"
                >
                  <i className="fas fa-file-pdf mr-1"></i>
                  PDF
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => downloadReport("excel")}
                  data-testid="button-download-excel"
                >
                  <i className="fas fa-file-excel mr-1"></i>
                  Excel
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => downloadReport("csv")}
                  data-testid="button-download-csv"
                >
                  <i className="fas fa-file-csv mr-1"></i>
                  CSV
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border premium-shadow" data-testid="card-total-invested">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-pie text-primary text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
                {filteredInvestments.length}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-foreground" data-testid="text-report-invested">
              {formatCurrency(totalInvested)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Investido</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-expected-returns">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-trending-up text-green-400 text-xl"></i>
              </div>
              <span className="text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">
                200%
              </span>
            </div>
            <h3 className="text-2xl font-bold text-green-400" data-testid="text-report-returns">
              {formatCurrency(totalExpectedReturns)}
            </h3>
            <p className="text-sm text-muted-foreground">Retorno Esperado</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-profit">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-trophy text-primary text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">
                +{totalInvested > 0 ? Math.round((totalProfit / totalInvested) * 100) : 0}%
              </span>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-report-profit">
              {formatCurrency(totalProfit)}
            </h3>
            <p className="text-sm text-muted-foreground">Lucro Total</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-roi">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-percentage text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-report-roi">
              {totalInvested > 0 ? Math.round((totalProfit / totalInvested) * 100) : 0}%
            </h3>
            <p className="text-sm text-muted-foreground">ROI Médio</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Investment Summary */}
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-chart-line text-primary mr-3"></i>
              Resumo de Investimentos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Investimentos Ativos:</span>
                <span className="font-semibold text-green-400" data-testid="text-active-investments">
                  {activeInvestments}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Investimentos Concluídos:</span>
                <span className="font-semibold" data-testid="text-completed-investments">
                  {completedInvestments}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Valor Médio por Investimento:</span>
                <span className="font-semibold" data-testid="text-average-investment">
                  {formatCurrency(filteredInvestments.length > 0 ? totalInvested / filteredInvestments.length : 0)}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-muted-foreground">Taxa de Sucesso:</span>
                <span className="font-semibold text-green-400" data-testid="text-success-rate">
                  {filteredInvestments.length > 0 ? 
                    Math.round((completedInvestments / filteredInvestments.length) * 100) : 0}%
                </span>
              </div>
            </div>

            {/* Performance Chart Placeholder */}
            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-4">Performance no Período</h4>
              <div className="bg-muted/30 rounded-lg h-48 flex items-center justify-center">
                <div className="text-center">
                  <i className="fas fa-chart-area text-primary text-3xl mb-2"></i>
                  <p className="text-muted-foreground">Gráfico de Performance</p>
                  <p className="text-sm text-muted-foreground">
                    {filteredInvestments.length} investimento{filteredInvestments.length !== 1 ? 's' : ''} no período
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Financial Summary */}
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-wallet text-primary mr-3"></i>
              Resumo Financeiro
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Total de Depósitos:</span>
                <span className="font-semibold text-green-400" data-testid="text-report-deposits">
                  {formatCurrency(totalDeposits)}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Total de Saques:</span>
                <span className="font-semibold text-orange-400" data-testid="text-report-withdrawals">
                  {formatCurrency(totalWithdrawals)}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-border">
                <span className="text-muted-foreground">Fluxo Líquido:</span>
                <span className={`font-semibold ${totalDeposits - totalWithdrawals >= 0 ? 'text-green-400' : 'text-red-400'}`} data-testid="text-net-flow">
                  {formatCurrency(totalDeposits - totalWithdrawals)}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-muted-foreground">Saldo Atual:</span>
                <span className="font-semibold text-primary" data-testid="text-current-balance">
                  {formatCurrency(parseFloat(user?.balance || "0"))}
                </span>
              </div>
            </div>

            {/* Transaction Breakdown */}
            <div className="mt-6">
              <h4 className="text-lg font-semibold mb-4">Transações no Período</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-500/10 rounded-lg p-4 text-center">
                  <i className="fas fa-arrow-down text-green-400 text-2xl mb-2"></i>
                  <p className="text-sm text-muted-foreground">Depósitos</p>
                  <p className="font-bold text-green-400" data-testid="text-deposits-count">
                    {deposits.length}
                  </p>
                </div>
                <div className="bg-orange-500/10 rounded-lg p-4 text-center">
                  <i className="fas fa-arrow-up text-orange-400 text-2xl mb-2"></i>
                  <p className="text-sm text-muted-foreground">Saques</p>
                  <p className="font-bold text-orange-400" data-testid="text-withdrawals-count">
                    {withdrawals.length}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tables */}
      {filteredInvestments.length > 0 && (
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-table text-primary mr-3"></i>
              Detalhamento de Investimentos ({filteredInvestments.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-2 font-semibold text-primary">Data</th>
                    <th className="text-left py-3 px-2 font-semibold text-primary">Plano</th>
                    <th className="text-left py-3 px-2 font-semibold text-primary">Investimento</th>
                    <th className="text-left py-3 px-2 font-semibold text-primary">Retorno Esperado</th>
                    <th className="text-left py-3 px-2 font-semibold text-primary">Status</th>
                    <th className="text-left py-3 px-2 font-semibold text-primary">Vencimento</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredInvestments.map((investment: any, index: number) => (
                    <tr key={investment.id} className="hover:bg-muted/30 transition-colors" data-testid={`investment-report-row-${index}`}>
                      <td className="py-3 px-2 text-sm">
                        {new Date(investment.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="py-3 px-2 text-sm">Plano Mammon Premium</td>
                      <td className="py-3 px-2 text-sm font-semibold">
                        {formatCurrency(parseFloat(investment.amount))}
                      </td>
                      <td className="py-3 px-2 text-sm font-semibold text-green-400">
                        {formatCurrency(parseFloat(investment.expectedReturn))}
                      </td>
                      <td className="py-3 px-2 text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          investment.status === 'active' ? 'bg-green-500/10 text-green-400' :
                          investment.status === 'completed' ? 'bg-primary/10 text-primary' :
                          'bg-orange-500/10 text-orange-400'
                        }`}>
                          {investment.status === 'active' ? 'Ativo' : 
                           investment.status === 'completed' ? 'Concluído' : 'Pendente'}
                        </span>
                      </td>
                      <td className="py-3 px-2 text-sm">
                        {investment.maturityDate ? 
                          new Date(investment.maturityDate).toLocaleDateString('pt-BR') : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
