import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatCountdown } from "@/lib/utils";
import { useEffect, useState } from "react";

export default function DashboardTab() {
  const [currentTime, setCurrentTime] = useState(new Date());

  const { data: investments = [] } = useQuery({
    queryKey: ["/api/investments"],
  });

  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const balance = user?.balance ? parseFloat(user.balance) : 0;
  const activeInvestments = investments.filter((inv: any) => inv.status === "active");
  const totalInvested = investments.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount || "0"), 0);
  const totalExpectedReturn = investments.reduce((sum: number, inv: any) => sum + parseFloat(inv.expectedReturn || "0"), 0);
  const totalProfit = totalExpectedReturn - totalInvested;

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          Bem-vindo ao <span className="text-primary">MAMMON</span>
        </h2>
        <p className="text-muted-foreground">Sua plataforma premium de investimentos de alta rentabilidade</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-card border-border premium-shadow" data-testid="card-balance">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-wallet text-primary text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">Ativo</span>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-total-balance">
              {formatCurrency(balance)}
            </h3>
            <p className="text-sm text-muted-foreground">Saldo Total</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-active-investments">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-line text-primary text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">Ativo</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground" data-testid="text-active-count">
              {activeInvestments.length}
            </h3>
            <p className="text-sm text-muted-foreground">Investimentos Ativos</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-profit">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-trophy text-primary text-xl"></i>
              </div>
              <span className="text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">200%</span>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-total-profit">
              {formatCurrency(totalProfit)}
            </h3>
            <p className="text-sm text-muted-foreground">Lucro Total</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-next-maturity">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-clock text-primary text-xl"></i>
              </div>
              <span className="text-xs text-orange-400 bg-orange-400/10 px-2 py-1 rounded-full">Próximo</span>
            </div>
            <h3 className="text-2xl font-bold text-foreground">
              {activeInvestments.length > 0 ? "2 dias" : "N/A"}
            </h3>
            <p className="text-sm text-muted-foreground">Próximo Vencimento</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Investments and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Investments */}
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-chart-pie text-primary mr-3"></i>
              Investimentos Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {activeInvestments.length === 0 ? (
              <div className="text-center py-8">
                <i className="fas fa-chart-line text-muted-foreground text-3xl mb-4"></i>
                <p className="text-muted-foreground">Nenhum investimento ativo</p>
                <p className="text-sm text-muted-foreground">Faça seu primeiro investimento para começar</p>
              </div>
            ) : (
              <div className="space-y-4">
                {activeInvestments.map((investment: any, index: number) => {
                  const maturityDate = new Date(investment.maturityDate);
                  const countdown = formatCountdown(maturityDate);
                  
                  return (
                    <div key={investment.id} className="bg-muted/50 rounded-lg p-4 border border-border" data-testid={`investment-${index}`}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">Plano Mammon Premium</span>
                        <span className="status-ativo text-xs px-2 py-1 rounded-full">Ativo</span>
                      </div>
                      <div className="flex justify-between text-sm text-muted-foreground mb-3">
                        <span>Valor: {formatCurrency(parseFloat(investment.amount))}</span>
                        <span>Retorno: {formatCurrency(parseFloat(investment.expectedReturn))}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <i className="fas fa-clock text-primary text-sm"></i>
                          <span className="text-sm countdown-digit font-bold" data-testid={`countdown-${index}`}>
                            {countdown}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">Vencimento</div>
                          <div className="text-sm font-medium">
                            {maturityDate.toLocaleDateString('pt-BR')}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-bolt text-primary mr-3"></i>
              Ações Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Button 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-4 px-6 h-auto"
                data-testid="button-new-investment"
              >
                <i className="fas fa-plus mr-2"></i>
                Novo Investimento
              </Button>

              <Button 
                variant="secondary"
                className="w-full bg-muted hover:bg-muted/80 text-foreground font-medium py-4 px-6 h-auto"
                data-testid="button-calculator"
              >
                <i className="fas fa-calculator mr-2"></i>
                Calcular Rendimento
              </Button>

              <Button 
                variant="secondary"
                className="w-full bg-muted hover:bg-muted/80 text-foreground font-medium py-4 px-6 h-auto"
                data-testid="button-deposit"
              >
                <i className="fas fa-credit-card mr-2"></i>
                Depositar Fundos
              </Button>

              <Button 
                variant="secondary"
                className="w-full bg-muted hover:bg-muted/80 text-foreground font-medium py-4 px-6 h-auto"
                data-testid="button-report"
              >
                <i className="fas fa-download mr-2"></i>
                Gerar Relatório
              </Button>
            </div>

            {/* Performance Chart Placeholder */}
            <div className="mt-8">
              <h4 className="text-lg font-semibold mb-4">Performance (últimos 30 dias)</h4>
              <div className="bg-muted/30 rounded-lg h-48 flex items-center justify-center">
                <div className="text-center">
                  <i className="fas fa-chart-area text-primary text-3xl mb-2"></i>
                  <p className="text-muted-foreground">Gráfico de Performance</p>
                  <p className="text-sm text-muted-foreground">+{totalProfit > 0 ? '200' : '0'}% de rendimento</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
