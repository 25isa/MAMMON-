import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatCurrency, formatCountdown } from "@/lib/utils";
import { useEffect, useState } from "react";

export default function InvestimentosTab() {
  const [currentTime, setCurrentTime] = useState(new Date());

  const { data: investments = [], isLoading } = useQuery({
    queryKey: ["/api/investments"],
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["/api/transactions"],
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: "Ativo", variant: "default", className: "status-ativo" },
      pending: { label: "Pendente", variant: "secondary", className: "status-pendente" },
      completed: { label: "Finalizado", variant: "outline", className: "bg-green-500/10 text-green-400" },
      cancelled: { label: "Cancelado", variant: "destructive", className: "" },
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    
    return (
      <Badge 
        variant={config.variant as any}
        className={`text-xs px-2 py-1 ${config.className}`}
        data-testid={`status-${status}`}
      >
        {config.label}
      </Badge>
    );
  };

  const activeInvestments = investments.filter((inv: any) => inv.status === "active");
  const completedInvestments = investments.filter((inv: any) => inv.status === "completed");
  const totalInvested = investments.reduce((sum: number, inv: any) => sum + parseFloat(inv.amount || "0"), 0);
  const totalReturns = completedInvestments.reduce((sum: number, inv: any) => sum + parseFloat(inv.actualReturn || inv.expectedReturn || "0"), 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-primary text-3xl mb-4"></i>
          <p className="text-muted-foreground">Carregando investimentos...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">
          Meus <span className="text-primary">Investimentos</span>
        </h2>
        <p className="text-muted-foreground">Acompanhe o desempenho de todos os seus investimentos</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-card border-border premium-shadow" data-testid="card-total-invested">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-chart-pie text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-foreground" data-testid="text-total-invested">
              {formatCurrency(totalInvested)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Investido</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-active-count">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-clock text-green-400 text-xl"></i>
              </div>
              <span className="text-xs text-green-400 bg-green-400/10 px-2 py-1 rounded-full">Ativos</span>
            </div>
            <h3 className="text-2xl font-bold text-green-400" data-testid="text-active-investments">
              {activeInvestments.length}
            </h3>
            <p className="text-sm text-muted-foreground">Investimentos Ativos</p>
          </CardContent>
        </Card>

        <Card className="bg-card border-border premium-shadow" data-testid="card-total-returns">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <i className="fas fa-trophy text-primary text-xl"></i>
              </div>
            </div>
            <h3 className="text-2xl font-bold text-primary" data-testid="text-total-returns">
              {formatCurrency(totalReturns)}
            </h3>
            <p className="text-sm text-muted-foreground">Total Retornado</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Investments */}
      {activeInvestments.length > 0 && (
        <Card className="bg-card border-border premium-shadow">
          <CardHeader>
            <CardTitle className="flex items-center">
              <i className="fas fa-chart-line text-primary mr-3"></i>
              Investimentos Ativos ({activeInvestments.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeInvestments.map((investment: any, index: number) => {
                const maturityDate = new Date(investment.maturityDate);
                const countdown = formatCountdown(maturityDate);
                const profit = parseFloat(investment.expectedReturn) - parseFloat(investment.amount);
                
                return (
                  <div 
                    key={investment.id} 
                    className="bg-muted/50 rounded-lg p-4 border border-border"
                    data-testid={`active-investment-${index}`}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-foreground">Plano Mammon Premium</h4>
                          {getStatusBadge(investment.status)}
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-muted-foreground block">Investido</span>
                            <span className="font-medium">{formatCurrency(parseFloat(investment.amount))}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground block">Retorno Esperado</span>
                            <span className="font-medium text-green-400">{formatCurrency(parseFloat(investment.expectedReturn))}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground block">Lucro</span>
                            <span className="font-medium text-primary">{formatCurrency(profit)}</span>
                          </div>
                          <div>
                            <span className="text-muted-foreground block">Vencimento</span>
                            <span className="font-medium">{maturityDate.toLocaleDateString('pt-BR')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-3 border-t border-border">
                      <div className="flex items-center space-x-2">
                        <i className="fas fa-clock text-primary text-sm"></i>
                        <span className="text-sm font-medium">Tempo restante:</span>
                        <span className="text-sm countdown-digit font-bold" data-testid={`countdown-active-${index}`}>
                          {countdown}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <i className="fas fa-calendar text-primary"></i>
                        <span>Iniciado em {new Date(investment.startDate).toLocaleDateString('pt-BR')}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Investments History */}
      <Card className="bg-card border-border premium-shadow">
        <CardHeader>
          <CardTitle className="flex items-center">
            <i className="fas fa-history text-primary mr-3"></i>
            Histórico Completo ({investments.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {investments.length === 0 ? (
            <div className="text-center py-12">
              <i className="fas fa-chart-pie text-muted-foreground text-4xl mb-4"></i>
              <h3 className="text-lg font-semibold mb-2">Nenhum investimento encontrado</h3>
              <p className="text-muted-foreground mb-6">Faça seu primeiro investimento para começar</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-primary">Data</th>
                    <th className="text-left py-3 px-4 font-semibold text-primary">Plano</th>
                    <th className="text-left py-3 px-4 font-semibold text-primary">Valor</th>
                    <th className="text-left py-3 px-4 font-semibold text-primary">Retorno</th>
                    <th className="text-left py-3 px-4 font-semibold text-primary">Status</th>
                    <th className="text-left py-3 px-4 font-semibold text-primary">Vencimento</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {investments.map((investment: any, index: number) => (
                    <tr 
                      key={investment.id}
                      className="hover:bg-muted/30 transition-colors"
                      data-testid={`investment-row-${index}`}
                    >
                      <td className="py-3 px-4 text-sm">
                        {new Date(investment.createdAt).toLocaleDateString('pt-BR')}
                      </td>
                      <td className="py-3 px-4 text-sm font-medium">
                        Plano Mammon Premium
                      </td>
                      <td className="py-3 px-4 text-sm font-semibold">
                        {formatCurrency(parseFloat(investment.amount))}
                      </td>
                      <td className="py-3 px-4 text-sm font-semibold text-green-400">
                        {formatCurrency(parseFloat(investment.expectedReturn))}
                      </td>
                      <td className="py-3 px-4">
                        {getStatusBadge(investment.status)}
                      </td>
                      <td className="py-3 px-4 text-sm">
                        {investment.maturityDate ? new Date(investment.maturityDate).toLocaleDateString('pt-BR') : 'N/A'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
