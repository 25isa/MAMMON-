import { useAuth } from "@/hooks/useAuth";
import { formatCurrency } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { Button } from "./ui/button";

export default function Header() {
  const { user } = useAuth();
  
  const { data: userProfile } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: !!user,
  });

  const balance = userProfile?.balance ? parseFloat(userProfile.balance) : 0;
  const displayName = userProfile?.fullName || userProfile?.firstName || "Usuário";

  return (
    <header className="bg-card border-b border-border premium-shadow">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 gold-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-crown text-primary-foreground text-xl"></i>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-primary">MAMMON</h1>
              <p className="text-sm text-muted-foreground font-medium">INVESTIMENTOS</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center space-x-2 bg-muted px-4 py-2 rounded-lg">
              <i className="fas fa-wallet text-primary"></i>
              <span className="text-sm text-muted-foreground">Saldo:</span>
              <span className="font-bold text-primary" data-testid="text-balance">
                {formatCurrency(balance)}
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <i className="fas fa-user text-primary-foreground text-sm"></i>
              </div>
              <span className="hidden md:block text-sm font-medium" data-testid="text-username">
                {displayName}
              </span>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.location.href = '/api/logout'}
                className="ml-2"
                data-testid="button-logout"
              >
                <i className="fas fa-sign-out-alt text-muted-foreground"></i>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
