import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import DashboardTab from "./tabs/DashboardTab";
import CadastroTab from "./tabs/CadastroTab";
import PlanoMammonTab from "./tabs/PlanoMammonTab";
import InvestimentosTab from "./tabs/InvestimentosTab";
import CalculadoraTab from "./tabs/CalculadoraTab";
import ContaTab from "./tabs/ContaTab";
import FinanceiroTab from "./tabs/FinanceiroTab";
import RelatoriosTab from "./tabs/RelatoriosTab";
import AdminTab from "./tabs/AdminTab";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";

export default function TabNavigation() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: userProfile } = useQuery({
    queryKey: ["/api/auth/user"],
    enabled: !!user,
  });

  const isAdmin = userProfile?.isAdmin || false;
  const isRegistered = userProfile?.cpf ? true : false;

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "fas fa-chart-line", component: DashboardTab },
    { id: "cadastro", label: "Cadastro", icon: "fas fa-user-plus", component: CadastroTab, show: !isRegistered },
    { id: "plano-mammon", label: "Plano Mammon", icon: "fas fa-crown", component: PlanoMammonTab, requiresRegistration: true },
    { id: "investimentos", label: "Investimentos", icon: "fas fa-chart-pie", component: InvestimentosTab, requiresRegistration: true },
    { id: "calculadora", label: "Calculadora", icon: "fas fa-calculator", component: CalculadoraTab },
    { id: "conta", label: "Conta", icon: "fas fa-user-cog", component: ContaTab, requiresRegistration: true },
    { id: "financeiro", label: "Financeiro", icon: "fas fa-credit-card", component: FinanceiroTab, requiresRegistration: true },
    { id: "relatorios", label: "Relatórios", icon: "fas fa-file-chart-column", component: RelatoriosTab, requiresRegistration: true },
    { id: "admin", label: "Admin", icon: "fas fa-shield-alt", component: AdminTab, show: isAdmin },
  ];

  const visibleTabs = tabs.filter(tab => {
    if (tab.show === false) return false;
    if (tab.show === true) return true;
    if (tab.requiresRegistration && !isRegistered) return false;
    return tab.show !== false;
  });

  return (
    <div className="min-h-screen">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        {/* Tab Navigation */}
        <div className="bg-card border-b border-border sticky top-0 z-50">
          <div className="container mx-auto px-4">
            <TabsList className="h-auto p-0 bg-transparent w-full justify-start overflow-x-auto scrollbar-hide">
              {visibleTabs.map((tab) => (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className={`
                    flex items-center space-x-2 px-6 py-4 text-sm font-medium 
                    whitespace-nowrap transition-all duration-300 rounded-none
                    border-b-3 border-transparent
                    data-[state=active]:border-b-primary data-[state=active]:bg-primary/10
                    hover:bg-muted/50
                  `}
                  data-testid={`tab-${tab.id}`}
                >
                  <i className={`${tab.icon} text-current`}></i>
                  <span>{tab.label}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </div>

        {/* Tab Content */}
        <main className="container mx-auto px-4 py-8">
          {visibleTabs.map((tab) => {
            const Component = tab.component;
            return (
              <TabsContent key={tab.id} value={tab.id} className="mt-0">
                <Component />
              </TabsContent>
            );
          })}
        </main>
      </Tabs>
    </div>
  );
}
