export default function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-8 h-8 gold-gradient rounded-lg flex items-center justify-center">
              <i className="fas fa-crown text-primary-foreground text-sm"></i>
            </div>
            <div>
              <h3 className="font-bold text-primary">MAMMON INVESTIMENTOS</h3>
            </div>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Plataforma premium de investimentos de alta rentabilidade</p>
          <div className="flex justify-center space-x-6 text-xs text-muted-foreground">
            <a href="#" className="hover:text-primary transition-colors">Termos de Uso</a>
            <a href="#" className="hover:text-primary transition-colors">Política de Privacidade</a>
            <a href="#" className="hover:text-primary transition-colors">Suporte</a>
            <a href="#" className="hover:text-primary transition-colors">Contato</a>
          </div>
          <p className="text-xs text-muted-foreground mt-4">© 2024 Mammon Investimentos. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
