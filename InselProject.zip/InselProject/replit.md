# Overview

This is a premium investment platform called "MAMMON INVESTIMENTOS" built as a full-stack web application. The platform offers high-yield investment opportunities with promised returns of 200% in 3 days. It features user registration, investment management, financial transactions, admin controls, and comprehensive reporting capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite for build tooling
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom theming (dark mode by default)
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation
- **Design Pattern**: Component-based architecture with reusable UI components

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with consistent error handling middleware
- **Session Management**: Express session with PostgreSQL session store
- **File Structure**: Modular separation with shared schema definitions

## Authentication System
- **Provider**: Replit OpenID Connect (OIDC) integration
- **Strategy**: Passport.js with OpenID Connect strategy
- **Session Storage**: PostgreSQL-backed sessions using connect-pg-simple
- **Security**: HTTP-only secure cookies with CSRF protection
- **Authorization**: Role-based access control with admin privileges

## Database Design
- **Database**: PostgreSQL with Neon serverless hosting
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Tables**:
  - `users`: User profiles with financial data
  - `investment_plans`: Available investment packages
  - `investments`: User investment records
  - `transactions`: Financial transaction history
  - `sessions`: Authentication session storage
- **Data Validation**: Zod schemas for runtime type checking

## Core Features Architecture
- **Investment System**: Multi-tier investment plans with automatic return calculations
- **Transaction Management**: Deposit/withdrawal handling with multiple payment methods
- **Reporting System**: Comprehensive financial reporting with date range filtering
- **Admin Dashboard**: User management, investment oversight, and system administration
- **Real-time Updates**: Live countdown timers and dynamic balance updates

## External Dependencies

- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit OIDC service for user authentication
- **Session Storage**: PostgreSQL for persistent session management
- **UI Components**: Radix UI primitives for accessible component foundation
- **Styling**: Tailwind CSS for utility-first styling approach
- **Build Tools**: Vite for fast development and optimized production builds
- **Font Resources**: Google Fonts (Inter family) and Font Awesome icons
- **Development**: Replit-specific plugins for development environment integration