import {
  users,
  investments,
  investmentPlans,
  transactions,
  type User,
  type UpsertUser,
  type Investment,
  type InvestmentPlan,
  type Transaction,
  type InsertInvestment,
  type InsertTransaction,
  type InsertUser,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByCpf(cpf: string): Promise<User | undefined>;
  updateUser(id: string, user: Partial<User>): Promise<User>;
  registerUser(user: InsertUser): Promise<User>;
  
  // Investment plans
  getInvestmentPlans(): Promise<InvestmentPlan[]>;
  getInvestmentPlan(id: string): Promise<InvestmentPlan | undefined>;
  
  // Investments
  getUserInvestments(userId: string): Promise<Investment[]>;
  createInvestment(userId: string, investment: InsertInvestment): Promise<Investment>;
  updateInvestment(id: string, investment: Partial<Investment>): Promise<Investment>;
  getInvestment(id: string): Promise<Investment | undefined>;
  
  // Transactions
  getUserTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(userId: string, transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, transaction: Partial<Transaction>): Promise<Transaction>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getAllInvestments(): Promise<Investment[]>;
  getAllTransactions(): Promise<Transaction[]>;
  updateUserBalance(userId: string, amount: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByCpf(cpf: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.cpf, cpf));
    return user;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async registerUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        balance: "0.00",
        isAdmin: false,
      })
      .returning();
    return user;
  }

  // Investment plans
  async getInvestmentPlans(): Promise<InvestmentPlan[]> {
    return await db.select().from(investmentPlans).where(eq(investmentPlans.isActive, true));
  }

  async getInvestmentPlan(id: string): Promise<InvestmentPlan | undefined> {
    const [plan] = await db.select().from(investmentPlans).where(eq(investmentPlans.id, id));
    return plan;
  }

  // Investments
  async getUserInvestments(userId: string): Promise<Investment[]> {
    return await db
      .select()
      .from(investments)
      .where(eq(investments.userId, userId))
      .orderBy(desc(investments.createdAt));
  }

  async createInvestment(userId: string, investmentData: InsertInvestment): Promise<Investment> {
    const plan = await this.getInvestmentPlan(investmentData.planId);
    if (!plan) throw new Error("Investment plan not found");

    const amount = parseFloat(investmentData.amount);
    const expectedReturn = amount * (1 + parseFloat(plan.returnRate) / 100);
    
    const startDate = new Date();
    const maturityDate = new Date(startDate);
    maturityDate.setDate(maturityDate.getDate() + plan.durationDays);

    const [investment] = await db
      .insert(investments)
      .values({
        userId,
        planId: investmentData.planId,
        amount: investmentData.amount,
        expectedReturn: expectedReturn.toFixed(2),
        status: "active",
        startDate,
        maturityDate,
      })
      .returning();

    return investment;
  }

  async updateInvestment(id: string, investmentData: Partial<Investment>): Promise<Investment> {
    const [investment] = await db
      .update(investments)
      .set({ ...investmentData, updatedAt: new Date() })
      .where(eq(investments.id, id))
      .returning();
    return investment;
  }

  async getInvestment(id: string): Promise<Investment | undefined> {
    const [investment] = await db.select().from(investments).where(eq(investments.id, id));
    return investment;
  }

  // Transactions
  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async createTransaction(userId: string, transactionData: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values({
        userId,
        ...transactionData,
        status: "completed",
      })
      .returning();
    return transaction;
  }

  async updateTransaction(id: string, transactionData: Partial<Transaction>): Promise<Transaction> {
    const [transaction] = await db
      .update(transactions)
      .set({ ...transactionData, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    return transaction;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getAllInvestments(): Promise<Investment[]> {
    return await db.select().from(investments).orderBy(desc(investments.createdAt));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(desc(transactions.createdAt));
  }

  async updateUserBalance(userId: string, amount: string): Promise<void> {
    await db
      .update(users)
      .set({ balance: amount, updatedAt: new Date() })
      .where(eq(users.id, userId));
  }
}

export const storage = new DatabaseStorage();
