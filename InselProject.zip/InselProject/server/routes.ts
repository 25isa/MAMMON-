import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertUserSchema, insertInvestmentSchema, insertTransactionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User registration
  app.post("/api/register", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already registered
      const existingUser = await storage.getUser(userId);
      if (existingUser && existingUser.cpf) {
        return res.status(400).json({ message: "User already registered" });
      }

      // Check if CPF already exists
      const existingCpf = await storage.getUserByCpf(userData.cpf);
      if (existingCpf) {
        return res.status(400).json({ message: "CPF already registered" });
      }

      const user = await storage.updateUser(userId, userData);
      res.json(user);
    } catch (error) {
      console.error("Registration error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      res.status(400).json({ message: "Registration failed", error: errorMessage });
    }
  });

  // Investment plans
  app.get("/api/investment-plans", isAuthenticated, async (req, res) => {
    try {
      const plans = await storage.getInvestmentPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching investment plans:", error);
      res.status(500).json({ message: "Failed to fetch investment plans" });
    }
  });

  // User investments
  app.get("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investments = await storage.getUserInvestments(userId);
      res.json(investments);
    } catch (error) {
      console.error("Error fetching investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  app.post("/api/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const investmentData = insertInvestmentSchema.parse(req.body);
      
      const user = await storage.getUser(userId);
      if (!user || !user.cpf) {
        return res.status(400).json({ message: "User not fully registered" });
      }

      const userBalance = parseFloat(user.balance || "0");
      const investmentAmount = parseFloat(investmentData.amount);
      
      if (userBalance < investmentAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      const investment = await storage.createInvestment(userId, investmentData);
      
      // Update user balance
      const newBalance = (userBalance - investmentAmount).toFixed(2);
      await storage.updateUserBalance(userId, newBalance);
      
      // Create transaction record
      await storage.createTransaction(userId, {
        type: "investment",
        amount: investmentData.amount,
        description: `Investment in plan ${investmentData.planId}`,
      });

      res.json(investment);
    } catch (error) {
      console.error("Investment creation error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      res.status(400).json({ message: "Investment creation failed", error: errorMessage });
    }
  });

  // User transactions
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getUserTransactions(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactionData = insertTransactionSchema.parse(req.body);
      
      const transaction = await storage.createTransaction(userId, transactionData);
      
      // Update user balance for deposits/withdrawals
      if (transactionData.type === "deposit" || transactionData.type === "withdrawal") {
        const user = await storage.getUser(userId);
        const currentBalance = parseFloat(user?.balance || "0");
        const amount = parseFloat(transactionData.amount);
        
        const newBalance = transactionData.type === "deposit" 
          ? currentBalance + amount 
          : currentBalance - amount;
          
        if (newBalance < 0) {
          return res.status(400).json({ message: "Insufficient balance" });
        }
        
        await storage.updateUserBalance(userId, newBalance.toFixed(2));
      }

      res.json(transaction);
    } catch (error) {
      console.error("Transaction creation error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      res.status(400).json({ message: "Transaction creation failed", error: errorMessage });
    }
  });

  // Admin routes
  app.get("/api/admin/users", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/investments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const investments = await storage.getAllInvestments();
      res.json(investments);
    } catch (error) {
      console.error("Error fetching investments:", error);
      res.status(500).json({ message: "Failed to fetch investments" });
    }
  });

  app.get("/api/admin/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const transactions = await storage.getAllTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Create default investment plan if none exist
  app.post("/api/admin/setup", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      // This would be handled by direct database insertion in a real app
      // For now, just return success
      res.json({ message: "Setup completed" });
    } catch (error) {
      console.error("Setup error:", error);
      res.status(500).json({ message: "Setup failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
